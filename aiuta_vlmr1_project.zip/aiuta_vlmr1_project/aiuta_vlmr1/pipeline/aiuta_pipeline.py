"""
aiuta_pipeline.py — Main AIUTA orchestration loop.
Strategy pattern selects components from config.

Supports:
  - Embodied / detection-driven episodes (CoIN offline static integration tests)
  - Offline QA-style use is provided via ``evaluation.idkvqa_eval`` (primary benchmark)
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable

from ..config import Config, DetectorType, QuestionerType, TriggerType
from ..detector.base import AbstractDetector
from ..detector.vlmr1_detector import VLMr1Detector
from ..self_questioner.base import AbstractSelfQuestioner
from ..self_questioner.vlmr1_questioner import VLMr1SelfQuestioner
from ..self_questioner.two_pass_questioner import TwoPassSelfQuestioner
from ..interaction_trigger.base import AbstractInteractionTrigger, ActionType
from ..interaction_trigger.kg_trigger import KGInteractionTrigger
from ..knowledge_graph.scene_graph import SceneKnowledgeGraph


class PolicySignal(Enum):
    STOP = "stop"
    CONTINUE = "continue"


@dataclass
class PipelineStepResult:
    """Result of one ``on_detection`` call (introspection for offline runners)."""
    signal: PolicySignal
    num_raw_detections: int
    num_valid_detections: int
    detector_latency_sec: float | None
    detector_preprocess_sec: float | None
    detector_generate_sec: float | None
    detector_parse_sec: float | None
    asked_questions_in_step: int


class AIUTAPipeline:
    def __init__(self, config: Config, ask_human: Callable[[str], str] | None = None):
        self._config = config
        self._ask_human = ask_human or (lambda q: "I don't know")

        self._detector = self._create_detector(config)
        self._questioner = self._create_questioner(config)
        self._trigger = self._create_trigger(config)

        self._kg = SceneKnowledgeGraph()
        self._target_category = ""
        self._timestep = 0
        self._num_questions_asked = 0
        self._episode_log: list[dict] = []
        self._last_step_result: PipelineStepResult | None = None

    def _create_detector(self, config: Config) -> AbstractDetector:
        if config.detector_type == DetectorType.VLMR1:
            return VLMr1Detector(config)
        raise NotImplementedError(f"Detector {config.detector_type} not implemented")

    def _create_questioner(self, config: Config) -> AbstractSelfQuestioner:
        if config.questioner_type == QuestionerType.VLMR1:
            return VLMr1SelfQuestioner()
        if config.questioner_type == QuestionerType.TWO_PASS:
            return TwoPassSelfQuestioner(config)
        raise NotImplementedError(f"Questioner {config.questioner_type} not implemented")

    def _create_trigger(self, config: Config) -> AbstractInteractionTrigger:
        if config.trigger_type == TriggerType.KG:
            return KGInteractionTrigger(config.trigger)
        raise NotImplementedError(f"Trigger {config.trigger_type} not implemented")

    def set_ask_human(self, fn: Callable[[str], str]) -> None:
        """Replace the human callback (used by offline runners and tests)."""
        self._ask_human = fn

    def new_episode(self, target_category: str) -> None:
        self.reset_episode(target_category)

    def reset_episode(self, target_category: str) -> None:
        """Clear per-episode graph state and counters."""
        self._kg.reset()
        self._kg.target_facts.category = target_category
        self._target_category = target_category
        self._timestep = 0
        self._num_questions_asked = 0
        self._episode_log = []
        self._last_step_result = None

    def on_detection(self, observation, timestep: int) -> PipelineStepResult:
        self._timestep = timestep
        kg_context = self._kg.get_kg_context_string(self._target_category)

        if isinstance(observation, str):
            det_result = self._detector.detect(
                observation, [self._target_category], kg_context=kg_context
            )
        else:
            det_result = self._detector.detect_from_observation(
                observation, [self._target_category], kg_context=kg_context
            )

        asked_here = 0
        final_signal = PolicySignal.CONTINUE
        raw_n = len(det_result.detections)
        valid_n = 0

        for det in det_result.detections:
            refined = self._questioner.process(
                det, self._kg.target_facts, self._kg, timestep
            )

            if not refined.is_valid:
                continue
            valid_n += 1

            for round_idx in range(self._config.trigger.max_interaction_rounds):
                action = self._trigger.decide(
                    refined, self._kg.target_facts, self._kg
                )

                log_entry: dict[str, Any] = {
                    "timestep": timestep,
                    "detection": det.label,
                    "action": action.type.value,
                    "score": action.alignment_score,
                    "question": action.question,
                    "reason": action.reason,
                    "round": round_idx,
                    "alignment_explanation": action.alignment_explanation,
                }

                if action.type == ActionType.STOP:
                    self._episode_log.append(log_entry)
                    final_signal = PolicySignal.STOP
                    self._last_step_result = PipelineStepResult(
                        signal=final_signal,
                        num_raw_detections=raw_n,
                        num_valid_detections=valid_n,
                        detector_latency_sec=det_result.latency_sec,
                        detector_preprocess_sec=det_result.preprocess_latency_sec,
                        detector_generate_sec=det_result.generate_latency_sec,
                        detector_parse_sec=det_result.parse_latency_sec,
                        asked_questions_in_step=asked_here,
                    )
                    return self._last_step_result

                if action.type == ActionType.ASK:
                    response = self._ask_human(action.question or "")
                    self._kg.update_target_facts(response, timestep)
                    self._num_questions_asked += 1
                    asked_here += 1
                    log_entry["user_response"] = response
                    log_entry["target_facts_snapshot"] = {
                        "known": dict(self._kg.target_facts.known_attributes),
                        "negative": dict(self._kg.target_facts.negative_attributes),
                    }
                    self._episode_log.append(log_entry)
                else:
                    self._episode_log.append(log_entry)
                    break

        self._last_step_result = PipelineStepResult(
            signal=final_signal,
            num_raw_detections=raw_n,
            num_valid_detections=valid_n,
            detector_latency_sec=det_result.latency_sec,
            detector_preprocess_sec=det_result.preprocess_latency_sec,
            detector_generate_sec=det_result.generate_latency_sec,
            detector_parse_sec=det_result.parse_latency_sec,
            asked_questions_in_step=asked_here,
        )
        return self._last_step_result

    def get_episode_summary(self) -> dict[str, Any]:
        """Structured snapshot for logging (no private field access)."""
        tf = self._kg.target_facts
        out: dict[str, Any] = {
            "target_category": self._target_category,
            "timestep": self._timestep,
            "num_questions_asked": self._num_questions_asked,
            "num_kg_objects": self._kg.num_objects,
            "target_facts": {
                "category": tf.category,
                "num_facts": tf.num_facts,
                "asked_questions_count": len(tf.asked_questions),
                "fact_provenance": dict(tf.fact_provenance),
            },
            "episode_log_len": len(self._episode_log),
            "last_step": None,
        }
        if self._last_step_result is not None:
            ls = self._last_step_result
            out["last_step"] = {
                "signal": ls.signal.value,
                "num_raw_detections": ls.num_raw_detections,
                "num_valid_detections": ls.num_valid_detections,
                "detector_latency_sec": ls.detector_latency_sec,
                "detector_preprocess_sec": ls.detector_preprocess_sec,
                "detector_generate_sec": ls.detector_generate_sec,
                "detector_parse_sec": ls.detector_parse_sec,
                "asked_questions_in_step": ls.asked_questions_in_step,
            }
        return out

    @property
    def kg(self) -> SceneKnowledgeGraph:
        return self._kg

    @property
    def num_questions_asked(self) -> int:
        return self._num_questions_asked

    @property
    def episode_log(self) -> list[dict]:
        return list(self._episode_log)
